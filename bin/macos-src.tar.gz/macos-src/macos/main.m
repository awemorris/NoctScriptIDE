int main2(int argc, char *argv[]);

int main(int argc, char *argv[])
{
	return main2(argc, argv);
}
